def getAction(self, gameState):
    """
      Returns the minimax action from the current gameState using self.depth
      and self.evaluationFunction.

      Here are some method calls that might be useful when implementing minimax.

      gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

      gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

      gameState.getNumAgents():
        Returns the total number of agents in the game
    """
    "*** YOUR CODE HERE ***"
    _, action = self.max_value(gameState, 0)
    return action


def max_value(self, gameState, depth):
    legalM = gameState.getLegalActions(0)
    if len(legalM) == 0 or depth == self.depth:
        return gameState.getScore(), ""
    max_value = None
    max_action = ""
    for action in legalM:
        successor = gameState.generateSuccessor(0, action)
        value, _ = self.min_value(successor, 1, depth)

        if max_value is None or value > max_value:
            max_value = value
            max_action = action
    return max_value, max_action


def min_value(self, gameState, index, depth):
    legalM = gameState.getLegalActions(index)
    if len(legalM) == 0 or depth == self.depth:
        return gameState.getScore(), None
    min_value = None
    min_action = ""
    next_index = index + 1
    if next_index == gameState.getNumAgents():
        next_index = 0

    for action in legalM:
        successor = gameState.generateSuccessor(index, action)
        if next_index == 0:
            value, _ = self.max_value(successor, depth + 1)
        else:
            value, _ = self.min_value(successor, next_index, depth)

        if min_value is None or value < min_value:
            min_value = value
            min_action = action
    return min_value, min_action