def depthFirstSearch(problem):

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))

    stiva = util.Stack()
    start = problem.getStartState()
    visitate = []
    tupla = (start, [])
    stiva.push(tupla)
    while not stiva.isEmpty():
        stare, actiune = stiva.pop()
        if problem.isGoalState(stare):
            return actiune
        visitate.append(stare)
        copii = problem.getSuccessors(stare)
        for copil in copii:
            stareCopil = copil[0]
            directieCopil = copil[1]
            if not stareCopil in visitate:
                stiva.push((stareCopil, actiune + [directieCopil]))

    util.raiseNotDefined()