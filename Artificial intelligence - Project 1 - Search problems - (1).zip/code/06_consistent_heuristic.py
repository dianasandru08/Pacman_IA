def cornersHeuristic(state, problem):

    "*** YOUR CODE HERE ***"


    currentPoint, cornersV = state
    cornersnV = []
    heuristicL = []
    cost = 0
    curPoint, crns = state
    totalCost = 0;

    for c in problem.corners:
        if c not in cornersV:
            cornersnV.append(c)

    while cornersnV:
        for cor in cornersnV:
            cost, cornerCost = (util.manhattanDistance(curPoint, cor), cor)
            tupla = cost, cornerCost
            heuristicL.append(tupla)
        # print ("cor ramase:")
        # print(cornersnV)
        # print(heuristicL)
        heuristic_cost, corM = min(heuristicL)
        heuristicL = []
        # print("heuristica dupa stergere:")
        # print(heuristicL)
        # print(heuristic_cost)
        # print(corM)
        cornersnV.remove(corM)
        curPoint = corM
        totalCost += heuristic_cost
    return totalCost
