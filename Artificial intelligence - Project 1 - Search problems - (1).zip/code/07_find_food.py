def foodHeuristic(state, problem):
    
    position, foodGrid = state
    "*** YOUR CODE HERE ***"
    return 0