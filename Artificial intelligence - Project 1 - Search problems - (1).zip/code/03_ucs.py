def uniformCostSearch(problem):

    "*** YOUR CODE HERE ***"
    coadaP = util.PriorityQueue()
    start = problem.getStartState()
    visitedNodes = []
    coadaP.push((start, []), 0)
    while not coadaP.isEmpty():
        stare, actions = coadaP.pop()
        if stare not in visitedNodes:
            if problem.isGoalState(stare):
                return actions
            copii = problem.getSuccessors(stare)
            for copil in copii:
                stareCopil = copil[0]
                directieCopil = copil[1]
                if stareCopil not in visitedNodes:
                    visitedNodes.append(stare)
                    cost = problem.getCostOfActions(actions + [directieCopil])
                    coadaP.push((stareCopil, actions + [directieCopil]), cost)

    util.raiseNotDefined()