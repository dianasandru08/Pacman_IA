def evaluationFunction(self, currentGameState, action):
    """
    Design a better evaluation function here.

    The evaluation function takes in the current and proposed successor
    GameStates (pacman.py) and returns a number, where higher numbers are better.

    The code below extracts some useful information from the state, like the
    remaining food (newFood) and Pacman position after moving (newPos).
    newScaredTimes holds the number of moves that each ghost will remain
    scared because of Pacman having eaten a power pellet.

    Print out these variables to see what you're getting, then combine them
    to create a masterful evaluation function.
    """
    # Useful information you can extract from a GameState (pacman.py)
    successorGameState = currentGameState.generatePacmanSuccessor(action)

    # newFood = successorGameState.getFood()
    # newGhostStates = successorGameState.getGhostStates()
    # newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

    "*** YOUR CODE HERE ***"

    newPos = successorGameState.getPacmanPosition()
    newFood = successorGameState.getFood().asList()
    FoodL = []
    minFood = -1
    newGhostStates = successorGameState.getGhostStates()

    for food in newFood:
        distPacFood = manhattanDistance(newPos, food)
        if distPacFood <= minFood or minFood == -1:
            minFood = distPacFood

    # for food in newFood:
    # minFoodist = min(minFoodist, manhattanDistance(newPos, food))

    # avoid ghost if too close
    newGhostPosition = successorGameState.getGhostPositions()
    for ghost in newGhostPosition:
        distPacGhost = manhattanDistance(newPos, ghost)
        if (distPacGhost < 2):
            return -float('inf')
    # reciprocal
    return successorGameState.getScore() + 1.0 / minFood