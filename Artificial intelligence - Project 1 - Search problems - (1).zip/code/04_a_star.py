def aStarSearch(problem, heuristic=nullHeuristic):

    "*** YOUR CODE HERE ***"
    coadaP = util.PriorityQueue()
    start = problem.getStartState()
    visitedNodes = []
    coadaP.push((start, []), 0)
    while not coadaP.isEmpty():
        stare, actions = coadaP.pop()
        if stare not in visitedNodes:
            if problem.isGoalState(stare):
                return actions
            copii = problem.getSuccessors(stare)
            for copil in copii:
                stareCopil = copil[0]
                directieCopil = copil[1]
                if stareCopil not in visitedNodes:
                    visitedNodes.append(stare)
                    g = problem.getCostOfActions(actions + [directieCopil])
                    h = heuristic(stareCopil, problem)
                    prioritate = h + g
                    coadaP.push((stareCopil, actions + [directieCopil]), prioritate)

    util.raiseNotDefined()