def breadthFirstSearch(problem):

    "*** YOUR CODE HERE ***"
    frontier = util.Queue()
    state = problem.getStartState()
    expanded = []
    current = Node(state, None, None, 0)
    frontier.push(current)
    while (not frontier.isEmpty()):
        current = frontier.pop()
        expanded += [current.getState()]
        if problem.isGoalState(current.getState()):
            solution = []
            while (current.getParent()):
                solution += [current.getAction()]
                current = current.getParent()
            solution.reverse()
            return solution
        for (state, action, _) in problem.getSuccessors(current.getState()):
            newNode = Node(state, current, action, 0)
            if state not in expanded and newNode not in frontier.list:
                frontier.push(newNode)

    util.raiseNotDefined()